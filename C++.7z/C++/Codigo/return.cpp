#include <iostream>

double areaQua(double l);

int main() {

    double l = 2;

    double area = areaQua(l);
    
    std::cout<<"A area do quadrado cujo lado mede "<<l<<" cm es "<<area<<" cm^2.";

    return 0;
}

double areaQua(double l) {
return l * l;
}