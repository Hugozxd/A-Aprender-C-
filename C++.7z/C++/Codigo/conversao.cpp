#include <iostream>

int main() {

    double x = (int)3;
    x += 0.5;
    std::cout<< x;
    return 0;
}