#include <iostream>

namespace primeiro {
    int x = 1;
}
namespace segundo {
    int x = 2;
}

int main() {
    using namespace primeiro; // using namespace std; já não e preciso de usar o std::!
    std::cout<<"X = "<<x; // using std::cout; já não é preciso usar o std apenas no cout ou outros que escolhermos!

    return 0;
}