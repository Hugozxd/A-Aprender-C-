#include <iostream>

int main() {
    int x;  // Declaração
    x = 5;  // Atribuição

    // Ou tudo junto:
    int y = 1;

    std::cout << "A variável x tem valor " << x << "." << std::endl;
    std::cout << "A variável y tem valor " << y << "." << std::endl;

    int soma = x + y;
    std::cout << "A soma de x e y é " << soma << "." << std::endl;

    // Tipos de dados para números decimais:
    // double -> 64 bits, até 15 casas decimais.
    // float -> 32 bits, até 7 casas decimais.
    // long double -> maior precisão.
    // Algumas IDEs podem mostrar apenas 4 casas decimais.
    // Para armazenar um único caractere, usamos 'char'.
    char texto = 'A';
    std::cout<<texto <<std::endl;
    // São para variaveis que apeanas podem ter dois valores: verdadeiro ou falso (false; true;), são booleanos(bool).
    bool estudante = false;
    bool ligado = true;
    // Algo true tem valor 1, algo false tem valor 0. Exp;
    std::cout<<estudante <<std::endl;
    std::cout<<ligado <<std::endl;
    // Para frases/palavras/strings usamos o string.
    std::string nome = "Hugo";
    std::cout <<"Olá "<<nome <<".";
    return 0;
}
