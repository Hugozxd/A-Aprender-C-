#include <iostream>
#include <cmath>

int main() {
    double c1;
    double c2;
    double hp;
    std::cout<<"=*=*=*=*=*=*=*=*=*=*=*=*=*=*"<< std::endl;
    std::cout<<" Calculador de hipotenusa"<< std::endl;
    std::cout<<"=*=*=*=*=*=*=*=*=*=*=*=*=*=*"<< std::endl;
    
    std::cout<<"Qual o valor do cateto 1:";
    std::cin>> c1;

    std::cout<<"Qual o valor do cateto 2:";
    std::cin>> c2;
    
    std::cout<<"==========================" <<std::endl;
    
    double c1_inicial = c1;
    double c2_inical = c2;

    c1 = pow(c1, 2);
    c2 = pow(c2, 2);

    hp = sqrt(c1 + c2);

    std::cout<<"A hipotenusa do triangulo retangulo cujo catetos sao " << c1_inicial <<" e " << c2_inical << " e " <<hp << ".";

    std::cout<<"=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=";

    return 0;
}