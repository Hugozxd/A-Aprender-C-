#include <iostream>
int main() {
    std::cout<<"Olá mundo!"<<std::endl; // ou <<'\n';
    std::cout<<"Eu gosto de pizza!";
    return 0;
}





// comentário de uma linha 
/*
    Un
    comentário 
    de
    várias linhas
    ok!
*/