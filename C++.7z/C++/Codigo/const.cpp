#include <iostream>

int main() {

    const double PI = 3.14159;
    double raio = 10;
    double circunferencia = 2 * PI * raio;

    std::cout<<circunferencia<<" cm." <<std::endl;

    return 0;
}