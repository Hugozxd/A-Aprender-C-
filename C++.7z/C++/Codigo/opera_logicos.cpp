#include <iostream>

int main() {

    // && = comprova se as condições são verdadeiras.
    // || = comprova se pelo menos uma das condicões é verdadeira.
    // !  = inverte o estado lógico do seu operado,


    return 0;
}