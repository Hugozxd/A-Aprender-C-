#include <iostream>

int main() {

    int idade;

    std::cout<<"Qual a tua idade:";
    std::cin >> idade;

    if (idade >= 18)
    {
        std::cout<<"Parabens es adulto!";
    } else 
    {
        std::cout<<"Nao es maior de idade!";
    }
    


    return 0;
}