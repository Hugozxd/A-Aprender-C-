#include <iostream>

int main() {

    std::string nome;

    while(nome.empty()) {

        std::cout<<"Qual o teu nome:";
        std::getline(std::cin, nome);
    }

    std::cout<<"Ola "<<nome<<".";

    return 0;
}