#include <iostream>
    // cout << (operador de inserção)
    // cin  >> (operador de extração)  usado como input

int main() {

    std::string nome;
    int idade;
    std::cout << "Qual e o teu nome completo:";
    std::getline(std::cin, nome);
    std::cout << "Quantos anos tens " << nome <<" :" ;
    std::cin >> idade;
    std::cout << "Ola " <<nome << " ";
    std::cout << "tens " << idade << " anos de idade." << std::endl;
    std::cout << "TESTE";
    return 0;
}