#include <iostream>

void parabens(std::string nome, int idade);

int main() {

    std::string nome = "Hugo";
    int idade = 15;

    parabens(nome,idade);
}

void parabens(std::string nome, int idade) {

    std::cout<<"Parabens a voce!\n";
    std::cout<<"Parabens para o "<< nome<<"!!\n";
    std::cout<<"Parabens a voce!\n";
    std::cout<<"Parabens pelos "<<idade<<" anos de vida!!\n";
}