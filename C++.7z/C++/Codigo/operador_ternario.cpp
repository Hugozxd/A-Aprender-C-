#include <iostream>

int main () {

    int numero = 2;

    numero % 2 ? std::cout<<"Impar" : std::cout<<"Par";

    return 0;
}