#include <iostream>

typedef std::string text_t;
typedef std::cout print_t;

int main() {
    text_t nome = "HUGO";
    int x = 0;
    print_t x
    return 0;
}