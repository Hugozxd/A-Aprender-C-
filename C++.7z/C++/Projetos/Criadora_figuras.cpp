#include <iostream>

int main() {

    int filas;
    int colunas;
    char simbolo;

    std::cout<<"---------- CRIAR FIGURAS -----------\n";

    std::cout<<"Quantas filas:";
    std::cin >> filas;

    std::cout<<"Quantas colunas:";
    std::cin >> colunas;

    std::cout<<"Qual simbolo:";
    std::cin >> simbolo;

    for(int i = 1; i <= filas; i++) {
        for(int j = 1; j <= colunas; j++) {
            std::cout<<simbolo <<" ";
        }
        std::cout<<"\n";
    }

    std::cout<<"-------------------------------------";

    return 0;
}