#include <iostream>

int main() {

    char op;
    double n1;
    double n2;
    double resultado;
    std::cout<<"########## CALCULADORA ##########\n";

    std::cout<<"Qual operacao quer fazer(+ - / *):";
    std::cin >> op;

    std::cout<<"Qual o Numero 1:";
    std::cin >> n1;

    std::cout<<"Qual o Numero 2:";
    std::cin >> n2;
    switch (op)
    {
    case '+':
        resultado = n1 + n2;
        std::cout<<"O resultado e: "<<resultado<<".\n";
        break;
    case '-':
        resultado = n1 - n2;
        std::cout<<"O resultado e: "<<resultado<<".\n";
        break;
    case '/':
        if (n2 == 0)
        {
            std::cout<<"Erro ao calcular com numero zero!\n" ;
            break;
        } else {
            resultado = n1 / n2;
            std::cout<<"O resultado e: "<<resultado<<".\n";
            break;
        }
        
        break;
    case '*':
        resultado = n1 * n2;
        std::cout<<"O resultado e: "<<resultado<<".\n";
        break;
    default:
        std::cout<<"Escreva (+ - / *)!!!!!!";
        break;
    }
    std::cout<<"#################################";

    return 0;
}