#include <iostream>
#include <ctime>

int main() {

    int num;
    int tentativas = 0;
    int adivinho;

    srand(time(NULL));

    num = (rand() % 100) + 1;

    do {
        std::cout<<"Adivinhei um numero de 1 a 100, adivinha-o:";
        std::cin >> adivinho;

        tentativas += 1;

        if(adivinho > num) {
            std::cout<<"Mais pequeno!\n";
        } else if(adivinho == num) {
            std::cout<<"";
        }
        else {
            std::cout<<"Mais grande!\n";
        }

    } while(adivinho != num);
    
    std::cout<<"Parabens adivinhaste o numero que pensei, o numero era "<<num<<" "<<"fizeste "<<tentativas<<" tentativas"<<"para acertar";

    return 0;
}