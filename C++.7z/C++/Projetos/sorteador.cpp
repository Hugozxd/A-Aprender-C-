#include <iostream>
#include <ctime>

int main() {

    srand(time(0));

    int randNum = (rand() % 5) + 1;

    switch(randNum) {
        case 1:
            std::cout<<"Ganhaste uma coluna pt-390!!";
            break;
        case 2:
            std::cout<<"Ganhaste uma televisao mitashi meios estragada!!";
            break;
        case 3:
            std::cout<<"Ganhaste uma televisao que funciona!!";
            break;
        case 4:
            std::cout<<"Ganhaste um computador acer aspire 5732z!! \n";
            break;
        case 5:
            std::cout<<"Ganhaste um xiamio 13 5g!!";
            break;
    }

    return 0;
}