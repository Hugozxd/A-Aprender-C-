#include <iostream>

int main() {

    std::cout<<"########## CONVERSOR DE TEMPERATURA ##########\n";
    double temp;
    char op;

    std::cout<<"F = Fahrenheit\n";
    std::cout<<"C = Celsius\n";

    std::cout<<"Para qual deseja converter (F/C):";
    std::cin >> op;

    if (op == 'C' || op == 'c') {
        std::cout<<"Digite o valor em Farenheit que deseja converter:";
        std::cin >> temp;
        
        temp = (temp - 32) / 1.8;
        std::cout<<"O valor convertido e de "<< temp <<" graus Celsius!";
    } else {
        std::cout<<"Digite o valor em Celsius que deseja converter:";
        std::cin >> temp;

        temp = 1.8 * temp - 32;
        std::cout<<"O valor convertido e de "<< temp <<" Farenheit!\n";
    }
    
    std::cout<<"##############################################\n";

    return 0;
}